package Introduccion;//este es el paquete(carpeta), indica donde se encuentra la clase.

/*Cuando creamos una clase en Java usamos la palabra reservada public
seguido de la palabra class para decir que es una clase, esto para
declarar que la clase es publica, de acceso a cualquier clase sin
importar en donde se llame dentro del proyecto*/

/*El nombre de las clases en Java debe ir en mayúscula debido a las 
convenciones de nomenclatura establecidas para mejorar la claridad y la 
legibilidad del código. Según las reglas de Java, los nombres de las clases 
deben ser sustantivos y, si están compuestos por varias palabras, la primera 
letra de cada palabra debe estar en mayúscula.

    Esto permite identificar fácilmente las clases dentro del código y 
diferenciarlas de otros elementos como métodos o variables. Por ejemplo, 
una clase podría llamarse "MiPrimerPrograma".

    Además, esta convención ayuda a mantener un estilo uniforme en el código, 
lo que facilita el trabajo en equipo y el mantenimiento del software.*/

// Esta es una clase llamada "Cuerpo"
public class Cuerpo {
    // Aquí se pueden declarar atributos y métodos que pertenezcan a esta clase.
}

//un ejemplo basico es:

class Auto{
    //atributos
    String marca, modelo, matricula;
    int precio;
    
    //metodos
    public void Encender(){
        //encendido
    }
    public void Apagar(){
        //apagado
    }
    public void Cerrado(){
        //cerrado
    }
    public void Abierto(){
        //abierto
    }
}

/*fuentes:
Java y Eclipse - Toma de contacto de Eclipse. (2018, 7 noviembre). 
https://www.ediciones-eni.com/libro/java-y-eclipse-desarrolle-una-aplicacion-con-java-y-eclipse-2a-edicion-9782409016837/toma-de-contacto-de-eclipse
*/