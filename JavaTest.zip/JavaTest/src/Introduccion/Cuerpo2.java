package Introduccion;


public class Cuerpo2 {
    /*El método main en Java es importante porque es el punto de entrada principal de un programa,
      Cuando se ejecuta una clase Java, el sistema localiza y ejecuta el método main de esa clase.
        Este método es el lugar donde se inicia la ejecución del programa y desde donde se llaman
      a otros métodos según la lógica programada.
      Sin el método main, el programa no puede iniciarse ni ejecutarse correctamente, Además, el
      método main debe seguir una sintaxis específica: "public static void main(String[] args)",
      ya que cualquier modificación o omisión puede provocar errores de ejecución.*/
    public static void main(String[]args){
        //un ejemplo a continuacion
        System.out.println("Hola mundo");
    }
}

/*fuentes.

Ciberaula. (s. f.). 🥇🥇 Método Main en Java. https://www.ciberaula.com/cursos/java/metodo_main.php
*/